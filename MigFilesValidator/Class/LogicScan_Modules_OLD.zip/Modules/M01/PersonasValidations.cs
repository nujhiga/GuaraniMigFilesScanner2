﻿using GuaraniMigFilesScanner.Class.RulesSources;
using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M01
{
    public static class PersonasValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f)
            where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
                case PersonasEnum.cuit_cuil:
                    scService.ValidateCuitCuil(fd, l, f);
                    break;
                case PersonasEnum.nro_documento:
                    scService.ValidateNroDocumento(fd, l, f);
                    scService.ValidateNroDocumentoExistence(fd, l, f);
                    break;
                case PersonasEnum.usuario:
                    scService.ValidateUsuario(fd, l, f);
                    break;
                case PersonasEnum.colegio:
                    scService.ValidateColegio(fd, SIUGTables.sga_colegios_secundarios, l, f);
                    break;
                case PersonasEnum.colegio_otro:
                    scService.ValidateColegioOtro(fields, l, f);
                    break;
                case PersonasEnum.institucion:
                    scService.ValidateInstitucion(fd, l, f);
                    break;
                case PersonasEnum.institucion_otra:
                    scService.ValidateInstitucionOtra(fields, l, f);
                    break;
                case PersonasEnum.fecha_nacimiento:
                    scService.ValidateFechaNacimiento(fd, l, f);
                    break;
                case PersonasEnum.fecha_ingreso_pais:
                    scService.ValidateFechaIngresoPais(fields, l, f);
                    break;
                case PersonasEnum.localidad_nacimiento:
                    scService.ValidateLocalidad(fd, SIUGTables.mug_localidades, l, f);
                    break;
                case PersonasEnum.localidad:
                    scService.ValidateLocalidad(fd, SIUGTables.mug_localidades, l, f);
                    break;
                case PersonasEnum.email:
                    scService.ValidateEmail(fd, l, f);
                    break;
                case PersonasEnum.nacionalidad:
                    scService.ValidateNacionalidad(fd, l, f);
                    break;
                case PersonasEnum.pais_documento:
                    scService.ValidatePaisDocumento(fd, SIUGTables.mug_paises, l, f);
                    break;
                case PersonasEnum.pais_origen:
                    scService.ValidatePaisOrigen(fields, SIUGTables.mug_paises, l, f);
                    break;
                case PersonasEnum.tipo_documento:
                    scService.ValidateTipoDocumento(fd, SIUGTables.mdp_tipos_documentos, l, f);
                    break;
                case PersonasEnum.sexo:
                    scService.ValidateSexo(fd, l, f);
                    break;
                
            }
        }

    }
}
