﻿using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M03
{
    public static class ActividadesValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f)
            where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
                case ActividadesEnum.estado:
                    scService.ValidateActividadesEstado(fd, l, f);
                    break;
                case ActividadesEnum.disponible_para:
                    scService.ValidateActividadesDisponiblePara(fd, l, f);
                    break;
            }
        }

    }
}
