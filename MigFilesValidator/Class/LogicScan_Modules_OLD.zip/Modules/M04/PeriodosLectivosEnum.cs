﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M04
{
    public enum PeriodosLectivosEnum
    {
        nombre,
        descripcion,
        anio_academico,
        periodo_generico,
        fecha_inicio,
        fecha_fin,
        fecha_inicio_dictado,
        fecha_fin_dictado,
        fecha_tope_movimientos,
        fecha_inactivacion,
        fecha_publicacion_comision
    }
}
