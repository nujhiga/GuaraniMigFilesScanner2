﻿using GuaraniMigFilesScanner.Class.RulesSources;
using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M05
{
    public static class AlumnosValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f)
            where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
                case AlumnosEnum.legajo:
                    break;
                case AlumnosEnum.tipo_documento:
                    scService.ValidateTipoDocumento(fd, SIUGTables.mdp_tipos_documentos, l, f);
                    break;
                case AlumnosEnum.nro_documento:

                    FieldData<T> auxfd = fields.Where(a => a.FieldType.Equals(AlumnosEnum.propuesta)).ElementAt(0);

                    scService.ValidateDuplicatedAlumnos(fd, auxfd, l, f);

                    scService.ValidateNroDocumento(fd, l, f);
                    break;
                case AlumnosEnum.propuesta:
                    // Validate In Client Data Table 
                    break;
                case AlumnosEnum.plan_version_ingreso:
                    // Validate In Client Data Table 
                    break;
                case AlumnosEnum.plan_version_actual:
                    // Validate In Client Data Table 
                    break;
                case AlumnosEnum.ubicacion:
                    break;
                case AlumnosEnum.modalidad:
                    scService.ValidateIsCharInRange(fd, l, f, new[] { 'P', 'A' }); // = ValidateInSIUGTable
                    break;
                case AlumnosEnum.regular:
                    scService.ValidateIsCharInRange(fd, l, f, new[] { 'S', 'N' });
                    break;
                case AlumnosEnum.calidad:
                    scService.ValidateIsCharInRange(fd, l, f, new[] { 'A', 'P' }); // = ValidateInSIUGTable
                    break;
                case AlumnosEnum.anio_academico:
                    scService.ValidateIntegerDataType(fd, l, f, 4);
                    break;

                case AlumnosEnum.estado_inscripcion:
                    scService.ValidateIsCharInRange(fd, l, f, new[] { 'P', 'A', 'R' });
                    break;
                case AlumnosEnum.noreg_anio_academico:
                    break;
                case AlumnosEnum.noreg_fecha:
                case AlumnosEnum.pasivo_fecha:
                case AlumnosEnum.fecha_inscripcion:
                case AlumnosEnum.egre_fecha_egreso:
                case AlumnosEnum.plan_version_actual_fecha:
                    scService.ValidateDateFormat(fd, l, f);
                    break;
                case AlumnosEnum.noreg_causa:
                    break;
                case AlumnosEnum.pasivo_motivo:
                    break;
                case AlumnosEnum.egre_titulo:
                    break;
                case AlumnosEnum.egre_nro_expediente:
                    break;
                case AlumnosEnum.egre_promedio:
                    break;
                case AlumnosEnum.egre_promedio_sin_aplazos:
                    break;
                case AlumnosEnum.egre_observaciones:
                    break;
            }
        }
    }
}
