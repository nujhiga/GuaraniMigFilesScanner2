﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M06
{
    public enum InscCursadasEnums
    {
        comision_nombre,
        anio_academico,
        periodo_lectivo_nombre,
        actividad_codigo,
        tipo_documento,
        nro_documento,
        propuesta,
        plan_version,
        fecha_inscripcion,
        estado,
        instancia_regular,
        instancia_promocion
    }

}
