﻿using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M06
{

    public static class InscCursadasValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f)
            where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
                case InscCursadasEnums.actividad_codigo:
                    scService.ValidateActivityCodeExistence(fd, l, f);
                    break;
                case InscCursadasEnums.fecha_inscripcion:
                    scService.ValidateDateFormat(fd, l, f);
                    break;
                case InscCursadasEnums.periodo_lectivo_nombre:
                    scService.ValidatePeriodoNombreExistence(fd, l, f);
                    break;
                case InscCursadasEnums.estado:
                    scService.ValidateIsCharInRange(fd, l, f, new char[] { 'A', 'P' });
                    break;
                case InscCursadasEnums.instancia_promocion:
                case InscCursadasEnums.instancia_regular:
                    scService.ValidateIsCharInRange(fd, l, f, new char[] { 'S', 'N' });
                    break;
            }
        }
    }
}
