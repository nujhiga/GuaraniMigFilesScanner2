﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M08
{
    public enum ActasExamenDetalleEnum
    {
        nro_acta,
        nro_libro,
        tipo_documento,
        nro_documento,
        propuesta,
        plan_version,
        tipo_inscripcion,
        fecha,
        folio_fisico,
        folio,
        renglon,
        nota,
        resultado,
        observaciones
    }
}
