﻿using GuaraniMigFilesScanner.Class.RulesSources;
using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M08
{
    public static class ActasExamenDetalleValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f) 
            where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
               
                case ActasExamenDetalleEnum.nro_documento:

                    var tdoc = fields.SingleOrDefault(f => f.FieldType.Equals(ActasExamenDetalleEnum.tipo_documento));

                    scService.ValidatePersonaExists(tdoc, fd, l, f);

                    break;

                case ActasExamenDetalleEnum.propuesta:

                    tdoc = fields.SingleOrDefault(f => f.FieldType.Equals(ActasExamenDetalleEnum.tipo_documento));
                    var ndoc = fields.SingleOrDefault(f => f.FieldType.Equals(ActasExamenDetalleEnum.nro_documento));

                    scService.ValidateAlumnoExists(tdoc, ndoc, fd, l, f);


                    break;

            }


        }
    }
}
