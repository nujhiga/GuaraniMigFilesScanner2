﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M08
{
    public enum ActasExamenEnum
    {
        nro_acta,
        nro_libro,
        nro_tomo,
        renglones_folio,
        anio_academico,
        turno_examen_nombre,
        mesa_examen_nombre,
        actividad_codigo,
        fecha,
        Observaciones,
        escala_nota,
        estado
    }
}
