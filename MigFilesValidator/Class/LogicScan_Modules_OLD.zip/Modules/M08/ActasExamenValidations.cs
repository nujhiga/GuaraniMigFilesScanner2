﻿using GuaraniMigFilesScanner.Class.Scanner;
using GuaraniMigFilesScanner.Class.Scanner.FieldsData;
using System;
using System.Collections.Generic;
using System.Text;

namespace GuaraniMigFilesScanner.Class.Modules.M08
{
    public static class ActasExamenValidations
    {
        public static void Validate<T>(ScannerService<T> scService, FieldData<T>[] fields, int l, int f)
           where T : Enum
        {
            FieldData<T> fd = fields[f];

            switch (fd.FieldType)
            {
                case ActasExamenEnum.estado:
                    scService.ValidateIsCharInRange(fd, l, f, new[] { 'A', 'C' });
                    break;
                case ActasExamenEnum.fecha:
                    scService.ValidateDateFormat(fd, l, f);
                    break;
                case ActasExamenEnum.turno_examen_nombre:
                    scService.ValidatePeriodoNombreExistence(fd, l, f);
                    break;
                case ActasExamenEnum.actividad_codigo:
                    scService.ValidateActivityCodeExistence(fd, l, f);
                    break;
                case ActasExamenEnum.escala_nota:
                    scService.ValidateEscalaNotaExistence(fd, l, f);
                    break;
                case ActasCursadaEnum.anio_academico:
                    scService.ValidateAnioAcademicoExistence(fd, l, f);
                    break;
            }


        }
    }
}
